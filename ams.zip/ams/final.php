<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="custom.css">
  <script type="text/javascript" src="js/jquery.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
 <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
  <?php include 'fonts.php';?>-->
  <title>Attendance Management System</title>
</head>
<body>
<div class="container">
   <div class="container-fluid center head">
      <h1>Attendance Management System</h1>
   </div>
   <div class="container-fluid center mainin">
    <div id = "log">
       <form action="final.php" method="post">
        <label >Username</label><br>
         <input type = "text" name="uname"><br>
        <label>Department</label><br>
         <select style="width: 20%;padding: 5px;background: white;outline: none;font-size: 16px;" name="dept">
          <option value="CE"> Civil</option>
          <option value="CSE"> Computer Science</option>
          <option value="ME"> Mechanical</option>
          <option value="EEE"> Electrical</option>
          <option value="ECE"> Electronics</option>
          <option value="MME"> Metallurgy</option>
          <option value="PIE"> Production</option>
          <option value="DCA"> MCA</option>
         </select><br>
         <label>Course code</label><br>
         <input type = "text" name="cid"><br>
         <label style="color:white;">Semester </label><br>
          <select style="width: 20%;padding: 5px;background: white;outline: none;font-size: 16px;" name="semester">
          <option value="I"> I</option>
          <option value="II"> II</option>
          <option value="III"> III</option>
          <option value="IV"> IV</option>
          <option value="V"> V</option>
          <option value="VI"> VI</option>
          <option value="VII"> VII</option>
          <option value="VIII"> VIII</option>
         </select><br><br>
         <button type="submit" name="register">Assign</button>
       </form>
       <a href="index.php"><button>Home Page</button></a>
      <?php
           if(isset($_POST['register'])){
               include 'includes/auth.inc.php';
               include 'includes/allfunctions.inc.php';
               $fac = $_POST['uname'];
               $dept = $_POST['dept'];
               $ccode = strtoupper($_POST['cid']);
               $semester = $_POST['semester']; 

               if(user_exists($fac,'teacher')){
                   $sql = "SELECT dept FROM course WHERE courseid = '$ccode' and  sem = '$semester' ";
                   $result = mysqli_query($connect,$sql);
               
               if($result){
                
               if(mysqli_num_rows($result) == 0){
                
                  $query = "INSERT INTO `course` (`courseid`, `dept`, `faculty`,`sem`) VALUES ('$ccode', '$dept','$fac','$semester')";

                  $res = mysqli_query($connect, $query);
                  if(!$res ) {
                    echo '<p>Could not assign course!</p>';
                    
                     exit();
                  }
                  else{
                     echo '<p>Course assigned Successfully!</p>';
                  }
                }
                else echo '<p>Course already assigned!</p>';
              }
              else echo '<p>Error!</p>'; 
               }
               else echo '<p>Teacher is not registered</p>';
           }

        ?> 
    </div>
   </div>
</div>
</body>
</html>